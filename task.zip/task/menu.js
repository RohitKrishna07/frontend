function home() {
    open("index1.html");
}
function about() {
    window.open("About.html", "_self");
}
function service() {
    window.open("service.html", "_self");
}
function design() {
    window.open("design.html", "_self");
}
function contact() {
    window.open("contact.html", "_self");
}

// to open signup page
function openfile()
{
    window.open("signup.html","_self");
}

// To create new account
function signup() {

    var fn=document.getElementById("id1").value;
    var ln=document.getElementById("id2").value;
    var email= document.getElementById("id3").value;
    var password=document.getElementById("id4").value;
    var dob=document.getElementById("id5").value;
   

    localStorage.setItem("name",fn);
    localStorage.setItem("lastname",ln);
    localStorage.setItem("email",email);    
    localStorage.setItem("password",password);
    localStorage.setItem("dob",dob);
}

// to verify Credentials
function verify(){

    var email_Verify=document.getElementById("id1").value;
    var password_Verify=document.getElementById("id2").value;

    var email1=localStorage.getItem("email");
    var password1=localStorage.getItem("password");
    if(email1==email_Verify&& password1==password_Verify)
    {
        window.open("contact.html");
    }

    
}
