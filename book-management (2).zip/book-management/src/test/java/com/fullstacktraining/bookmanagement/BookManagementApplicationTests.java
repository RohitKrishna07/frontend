package com.fullstacktraining.bookmanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
