package com.fullstacktraining.bookmanagement.exceptionhandler;

public class BookNotFound extends RuntimeException{
	public BookNotFound(String message)
	{
		super(message);
	}

}
