package com.fullstacktraining.bookmanagement.exceptionhandler;

import java.time.LocalDateTime;

public class ApplicationError {
	private int errorCode;
	private String errorMessage;
	private LocalDateTime dateTime;
	
	
	public ApplicationError(int errorCode, String errorMessage, LocalDateTime dateTime) {
		super();
		this.errorCode = errorCode;
		this.errorMessage = errorMessage;
		this.dateTime = dateTime;
	}
	
	

}
