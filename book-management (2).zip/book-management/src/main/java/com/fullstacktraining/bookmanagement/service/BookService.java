package com.fullstacktraining.bookmanagement.service;

import java.util.List;

import com.fullstacktraining.bookmanagement.dtos.BookDto;
import com.fullstacktraining.bookmanagement.entity.Book;

public interface BookService {
	
	BookDto addBook(BookDto bto);
	BookDto getBookById(Integer id);
	BookDto updateBook(BookDto dto,int id);
	void deleteBook(Integer id);
	List<BookDto> getAllBooks(int pageNum,int pageSize);
	List<BookDto> findBooksByAuthor(String author);
	
	
	
}
