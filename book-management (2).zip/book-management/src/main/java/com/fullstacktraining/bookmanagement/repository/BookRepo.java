package com.fullstacktraining.bookmanagement.repository;

import java.util.List;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import com.fullstacktraining.bookmanagement.dtos.BookDto;
import com.fullstacktraining.bookmanagement.entity.Book;

@Repository
public interface BookRepo extends JpaRepository<Book, Integer> {

    Page<Book> findAll(Pageable pageable);
    // Define a native SQL query using @Query
    @Query
    (value = "SELECT * FROM book WHERE author = ?1", nativeQuery = true)
    List<BookDto> findBooksByAuthor(String author);

}
