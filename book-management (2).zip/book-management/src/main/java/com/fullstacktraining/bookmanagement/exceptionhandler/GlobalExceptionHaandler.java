package com.fullstacktraining.bookmanagement.exceptionhandler;

import java.time.LocalDateTime;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHaandler {
	@ExceptionHandler(value= {BookNotFound.class})
	public ResponseEntity<ApplicationError>exceptionHandler(){
		ApplicationError appError=new ApplicationError(404,"Boook Not Found",LocalDateTime.now());
		return new ResponseEntity<ApplicationError>(appError,HttpStatus.NOT_FOUND);
	}

}
