package com.fullstacktraining.bookmanagement.service;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.stereotype.Service;

import com.fullstacktraining.bookmanagement.dtos.BookDto;
import com.fullstacktraining.bookmanagement.entity.Book;
import com.fullstacktraining.bookmanagement.repository.BookRepo;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    @Autowired
    private BookRepo bookrepo;

    @Autowired
    private ModelMapper mapper;

    @Autowired
    private BookRepo bookRepo;

    @Override
    public BookDto getBookById(Integer id) {
    	Book book=null;
        Optional<Book> bookRepo = bookrepo.findById(id);
        if(bookRepo.isEmpty()) {
        	book=bookRepo.get();
        	}
		return mapper.map(book,BookDto.class);
    }
    
    @Override
    public List<BookDto> getAllBooks(int pageNum, int pageSize) {
        List<BookDto> bookDtos = new ArrayList<>();
        Pageable pageable = PageRequest.of(pageNum, pageSize);
        Page<Book> booksPage = bookrepo.findAll(pageable);
        List<Book> allBooks = booksPage.getContent();
        for (Book book : allBooks) {
            bookDtos.add(mapper.map(book, BookDto.class));
        }
        return bookDtos;
    }
    
    @Override
    public void deleteBook(Integer id) {
        bookrepo.deleteById(id);
		
    }

	@Override
	public BookDto addBook(BookDto bto) {
		Book book=mapper.map(bto,Book.class);
		bookrepo.save(book);
		return mapper.map(book, BookDto.class);
	}

	@Override
	public BookDto updateBook(BookDto dto, int id) {
		// TODO Auto-generated method stub
		BookDto dtoupdated=null;
		Optional<Book> opt1=bookrepo.findById(id);
		if(opt1.isPresent()) {
			Book book=mapper.map(dto,Book.class);
			bookrepo.save(book);
			dtoupdated=mapper.map(book,BookDto.class);
		}
		return dtoupdated;
	}
	
	@Override
    public List<BookDto> findBooksByAuthor(String author) {
        return bookRepo.findBooksByAuthor(author);
    }

   

  

}
