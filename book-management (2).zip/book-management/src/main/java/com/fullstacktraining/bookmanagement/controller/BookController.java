package com.fullstacktraining.bookmanagement.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import com.fullstacktraining.bookmanagement.dtos.BookDto;
import com.fullstacktraining.bookmanagement.service.BookService;

import java.util.List;

@RestController

public class BookController {

    @Autowired
    private BookService bookService;

    
    @GetMapping("/book/{bookId}")
    public ResponseEntity<BookDto> getBookById(@PathVariable int bookId) {
       return new ResponseEntity<BookDto>(bookService.getBookById(bookId),HttpStatus.FOUND);
    }
    
    @GetMapping("/allbooks")
    public ResponseEntity<List<BookDto>> getAllBooks(
            @RequestParam(value = "pageNum", defaultValue = "1") int pageNum,
            @RequestParam(value = "pageSize", defaultValue = "10") int pageSize,
    @RequestParam(value = "sortField", defaultValue = "bookName") String sortField,
    @RequestParam(value = "sortOrder", defaultValue = "asc") String sortOrder) {

// Create a Sort object based on the provided sorting parameters
Sort sort = Sort.by(sortOrder.equals("asc") ? Sort.Order.asc(sortField) : Sort.Order.desc(sortField));

// Create a Pageable object based on the provided pagination parameters
Pageable pageable = PageRequest.of(pageNum - 1, pageSize, sort);
{
        
        return new ResponseEntity<List<BookDto>>( bookService.getAllBooks(pageNum, pageSize),HttpStatus.FOUND);
    }
 }
//    @GetMapping("/byAuthor")
//    public ResponseEntity<List<BookDto>> getBooksByAuthor(@RequestParam String author) {
//        List<BookDto> books = bookService.findBooksByAuthor(author);
//        return ResponseEntity.ok(books);
//    }

    @PostMapping("/addbook")
    public ResponseEntity<BookDto> addBook(@RequestBody BookDto bookDto) {
    	return new ResponseEntity<BookDto>(bookService.addBook(bookDto),HttpStatus.ACCEPTED);
    }

    @PutMapping("/{bookId}")
    public ResponseEntity<BookDto> updateBook(@RequestBody BookDto bookDto, @PathVariable int bookId) {
        return new ResponseEntity<BookDto>(bookService.addBook(bookDto),HttpStatus.OK);
       
    }
    @DeleteMapping("/{bookId}")
    public void deleteBook(@PathVariable Integer bookId) {
        bookService.deleteBook(bookId);
       
    }
    


    
}
