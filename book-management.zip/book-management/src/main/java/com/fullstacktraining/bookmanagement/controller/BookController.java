package com.fullstacktraining.bookmanagement.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import com.fullstacktraining.bookmanagement.entity.Book;
import com.fullstacktraining.bookmanagement.service.BookService;

@RestController
@RequestMapping(value="/books")
public class BookController {
	
	@Autowired
	BookService bookservice;
	
	
	@PostMapping("/addbook")
	public Book addBook(@RequestBody Book book)
	{
		return bookservice.addBook(book);
	}
	
	@GetMapping("/{id}")
	public Book retriveBook(@PathVariable Integer id)
	{
		return bookservice.retriveBook(id);
	}
	
	@DeleteMapping("/{id}")
	public String deleteBook(@PathVariable Integer id) {
		return bookservice.deleteBook(id);
	}
	
	@GetMapping("/all")
	public List<Book> getAllBooks() {
	    return bookservice.getAllBooks();
	}

}
