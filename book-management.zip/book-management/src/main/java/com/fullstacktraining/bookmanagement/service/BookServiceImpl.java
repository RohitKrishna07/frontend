package com.fullstacktraining.bookmanagement.service;

import java.util.List;
import java.util.Optional;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import com.fullstacktraining.bookmanagement.entity.Book;
import com.fullstacktraining.bookmanagement.repository.BookRepo;

@Service
public class BookServiceImpl implements BookService{
	
	@Autowired
	BookRepo bookrepo;

	@Override
	public Book addBook(Book book) {
		return bookrepo.save(book);
	}

	@Override
	public Book retriveBook(Integer id) {
		Optional<Book> bookRepo=bookrepo.findById(id);
		if(bookRepo.isPresent())
		{
			return bookRepo.get();
		}
		else {
			return null;
		}
	}

	@Override
	public String deleteBook(Integer id) {
		bookrepo.deleteById(id);
		return "Book with id "+id+"is deleted Successfully";
	}

	@Override
	public List<Book> getAllBooks() {
		return (List<Book>) bookrepo.findAll();
	}

}
