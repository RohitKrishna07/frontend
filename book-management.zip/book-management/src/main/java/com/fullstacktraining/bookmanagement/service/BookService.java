package com.fullstacktraining.bookmanagement.service;

import java.util.List;

import com.fullstacktraining.bookmanagement.entity.Book;

public interface BookService {
	public Book addBook(Book book);
	public Book retriveBook(Integer id);
	public String deleteBook(Integer id);
	public List<Book> getAllBooks();

}
